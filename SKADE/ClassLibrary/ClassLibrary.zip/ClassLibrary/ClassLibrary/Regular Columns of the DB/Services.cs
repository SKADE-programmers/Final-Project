﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class Services
    {
        public int Id { get; set; }

        public string serNames { get; set; }

        public string serDescription { get; set; }

        public int serPrices { get; set; }

    }
}
