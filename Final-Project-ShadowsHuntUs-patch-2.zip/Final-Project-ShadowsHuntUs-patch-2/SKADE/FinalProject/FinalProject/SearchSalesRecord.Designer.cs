﻿namespace FinalProject
{
    partial class SearchSalesRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custFirstDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custLastDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custPhoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custCityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custPostalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custEmailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.emmasDataSet = new FinalProject.EmmasDataSet();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtCustomerFirstName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCustomerLastName = new System.Windows.Forms.TextBox();
            this.txtCustomerCity = new System.Windows.Forms.TextBox();
            this.lblCustomersCity = new System.Windows.Forms.Label();
            this.lbCustomerPhoneNumber = new System.Windows.Forms.Label();
            this.txtCustomerPhoneNumber = new System.Windows.Forms.TextBox();
            this.customerTableAdapter1 = new FinalProject.EmmasDataSetTableAdapters.customerTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emmasDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.custFirstDataGridViewTextBoxColumn,
            this.custLastDataGridViewTextBoxColumn,
            this.custPhoneDataGridViewTextBoxColumn,
            this.custAddressDataGridViewTextBoxColumn,
            this.custCityDataGridViewTextBoxColumn,
            this.custPostalDataGridViewTextBoxColumn,
            this.custEmailDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.customerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 184);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1064, 366);
            this.dataGridView1.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 125;
            // 
            // custFirstDataGridViewTextBoxColumn
            // 
            this.custFirstDataGridViewTextBoxColumn.DataPropertyName = "custFirst";
            this.custFirstDataGridViewTextBoxColumn.HeaderText = "custFirst";
            this.custFirstDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custFirstDataGridViewTextBoxColumn.Name = "custFirstDataGridViewTextBoxColumn";
            this.custFirstDataGridViewTextBoxColumn.ReadOnly = true;
            this.custFirstDataGridViewTextBoxColumn.Width = 125;
            // 
            // custLastDataGridViewTextBoxColumn
            // 
            this.custLastDataGridViewTextBoxColumn.DataPropertyName = "custLast";
            this.custLastDataGridViewTextBoxColumn.HeaderText = "custLast";
            this.custLastDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custLastDataGridViewTextBoxColumn.Name = "custLastDataGridViewTextBoxColumn";
            this.custLastDataGridViewTextBoxColumn.ReadOnly = true;
            this.custLastDataGridViewTextBoxColumn.Width = 125;
            // 
            // custPhoneDataGridViewTextBoxColumn
            // 
            this.custPhoneDataGridViewTextBoxColumn.DataPropertyName = "custPhone";
            this.custPhoneDataGridViewTextBoxColumn.HeaderText = "custPhone";
            this.custPhoneDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custPhoneDataGridViewTextBoxColumn.Name = "custPhoneDataGridViewTextBoxColumn";
            this.custPhoneDataGridViewTextBoxColumn.ReadOnly = true;
            this.custPhoneDataGridViewTextBoxColumn.Width = 125;
            // 
            // custAddressDataGridViewTextBoxColumn
            // 
            this.custAddressDataGridViewTextBoxColumn.DataPropertyName = "custAddress";
            this.custAddressDataGridViewTextBoxColumn.HeaderText = "custAddress";
            this.custAddressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custAddressDataGridViewTextBoxColumn.Name = "custAddressDataGridViewTextBoxColumn";
            this.custAddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.custAddressDataGridViewTextBoxColumn.Width = 125;
            // 
            // custCityDataGridViewTextBoxColumn
            // 
            this.custCityDataGridViewTextBoxColumn.DataPropertyName = "custCity";
            this.custCityDataGridViewTextBoxColumn.HeaderText = "custCity";
            this.custCityDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custCityDataGridViewTextBoxColumn.Name = "custCityDataGridViewTextBoxColumn";
            this.custCityDataGridViewTextBoxColumn.ReadOnly = true;
            this.custCityDataGridViewTextBoxColumn.Width = 125;
            // 
            // custPostalDataGridViewTextBoxColumn
            // 
            this.custPostalDataGridViewTextBoxColumn.DataPropertyName = "custPostal";
            this.custPostalDataGridViewTextBoxColumn.HeaderText = "custPostal";
            this.custPostalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custPostalDataGridViewTextBoxColumn.Name = "custPostalDataGridViewTextBoxColumn";
            this.custPostalDataGridViewTextBoxColumn.ReadOnly = true;
            this.custPostalDataGridViewTextBoxColumn.Width = 125;
            // 
            // custEmailDataGridViewTextBoxColumn
            // 
            this.custEmailDataGridViewTextBoxColumn.DataPropertyName = "custEmail";
            this.custEmailDataGridViewTextBoxColumn.HeaderText = "custEmail";
            this.custEmailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custEmailDataGridViewTextBoxColumn.Name = "custEmailDataGridViewTextBoxColumn";
            this.custEmailDataGridViewTextBoxColumn.ReadOnly = true;
            this.custEmailDataGridViewTextBoxColumn.Width = 125;
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "customer";
            this.customerBindingSource.DataSource = this.emmasDataSet;
            // 
            // emmasDataSet
            // 
            this.emmasDataSet.DataSetName = "EmmasDataSet";
            this.emmasDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(329, 77);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(295, 77);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtCustomerFirstName
            // 
            this.txtCustomerFirstName.Location = new System.Drawing.Point(163, 12);
            this.txtCustomerFirstName.Name = "txtCustomerFirstName";
            this.txtCustomerFirstName.Size = new System.Drawing.Size(148, 22);
            this.txtCustomerFirstName.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Customer First Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Customer Last Name:";
            // 
            // txtCustomerLastName
            // 
            this.txtCustomerLastName.Location = new System.Drawing.Point(164, 44);
            this.txtCustomerLastName.Name = "txtCustomerLastName";
            this.txtCustomerLastName.Size = new System.Drawing.Size(148, 22);
            this.txtCustomerLastName.TabIndex = 5;
            // 
            // txtCustomerCity
            // 
            this.txtCustomerCity.Location = new System.Drawing.Point(164, 73);
            this.txtCustomerCity.Name = "txtCustomerCity";
            this.txtCustomerCity.Size = new System.Drawing.Size(148, 22);
            this.txtCustomerCity.TabIndex = 6;
            // 
            // lblCustomersCity
            // 
            this.lblCustomersCity.AutoSize = true;
            this.lblCustomersCity.Location = new System.Drawing.Point(56, 76);
            this.lblCustomersCity.Name = "lblCustomersCity";
            this.lblCustomersCity.Size = new System.Drawing.Size(106, 17);
            this.lblCustomersCity.TabIndex = 7;
            this.lblCustomersCity.Text = "Customers City:";
            // 
            // lbCustomerPhoneNumber
            // 
            this.lbCustomerPhoneNumber.AutoSize = true;
            this.lbCustomerPhoneNumber.Location = new System.Drawing.Point(14, 104);
            this.lbCustomerPhoneNumber.Name = "lbCustomerPhoneNumber";
            this.lbCustomerPhoneNumber.Size = new System.Drawing.Size(129, 17);
            this.lbCustomerPhoneNumber.TabIndex = 8;
            this.lbCustomerPhoneNumber.Text = "Customer Phone #:";
            // 
            // txtCustomerPhoneNumber
            // 
            this.txtCustomerPhoneNumber.Location = new System.Drawing.Point(164, 104);
            this.txtCustomerPhoneNumber.Name = "txtCustomerPhoneNumber";
            this.txtCustomerPhoneNumber.Size = new System.Drawing.Size(148, 22);
            this.txtCustomerPhoneNumber.TabIndex = 9;
            // 
            // customerTableAdapter1
            // 
            this.customerTableAdapter1.ClearBeforeFill = true;
            // 
            // SearchSalesRecord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1088, 570);
            this.Controls.Add(this.txtCustomerPhoneNumber);
            this.Controls.Add(this.lbCustomerPhoneNumber);
            this.Controls.Add(this.lblCustomersCity);
            this.Controls.Add(this.txtCustomerCity);
            this.Controls.Add(this.txtCustomerLastName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCustomerFirstName);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dataGridView1);
            this.Name = "SearchSalesRecord";
            this.Text = "SearchSalesRecord";
            this.Load += new System.EventHandler(this.SearchSalesRecord_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emmasDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtCustomerFirstName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCustomerLastName;
        private System.Windows.Forms.TextBox txtCustomerCity;
        private System.Windows.Forms.Label lblCustomersCity;
        private System.Windows.Forms.Label lbCustomerPhoneNumber;
        private System.Windows.Forms.TextBox txtCustomerPhoneNumber;
        private EmmasDataSetTableAdapters.customerTableAdapter customerTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custFirstDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custLastDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custPhoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custCityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custPostalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custEmailDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private EmmasDataSet emmasDataSet;
    }
}