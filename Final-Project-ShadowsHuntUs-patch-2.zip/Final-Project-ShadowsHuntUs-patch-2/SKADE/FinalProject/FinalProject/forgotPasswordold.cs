﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataLibrary;
using DataLibrary.AuthDSTableAdapters;
using ClassLibrary;

namespace FinalProject
{
    public partial class forgotPassword : Form
    {
        public forgotPassword()
        {
            InitializeComponent();
        }

        private void forgotPassword_Load(object sender, EventArgs e)
        {
            
        }

        private void submit_Click(object sender, EventArgs e)
        {
           // Login login = new Login();
            AuthenticateTableAdapter authenticate = new AuthenticateTableAdapter();
            //login.logUser = username.Text;
            //login.logPass = pass.Text;
            try
            {

            }
            catch
            {

            }


        }
    }
}
