﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ClassLibrary;
using DataLibrary;

namespace FinalProject
{
    public partial class SearchSalesRecord : Form
    {
        public SearchSalesRecord()
        {
            InitializeComponent();
        }

        private void SearchSalesRecord_Load(object sender, EventArgs e)
        { 
            // TODO: This line of code loads data into the 'emmasDataSet.customer' table. You can move, or remove it, as needed.
            customerTableAdapter1.Fill(emmasDataSet.customer);

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source = (LocalDB)'\'MSSQLLocalDB; AttachDbFilename=" + "C:'\'Users'\'exbf1'\'OneDrive - NC'\'Final-Project-ShadowsHuntUs-patch-2'\'SKADE'\'FinalProject'\'FinalProject'\'Emmas.mdf" + ";Integrated Security = True");

            SqlDataAdapter custNew = new SqlDataAdapter("select * from customer Where custFirst Like '" + txtCustomerFirstName.Text + "' OR '" + txtCustomerLastName.Text + "' OR '" + txtCustomerCity.Text + "' OR  '" + txtCustomerPhoneNumber.Text.ToString() , con) ;
            DataTable dts = new DataTable();
            custNew.Fill(dts);
            dataGridView1.DataSource = dts;
        }
    }
}
