﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClassLibrary
{
    class Customers
    {
        public int ID { get; set; }

        public string custFirstName { get; set; }

        public string custLastName { get; set; }

        public int custPhoneNumber { get; set; }

        public string custAddressLocation { get; set; }

        public string custCityLocation { get; set; }

        public string custEmailAddress { get; set; }

    }
}
