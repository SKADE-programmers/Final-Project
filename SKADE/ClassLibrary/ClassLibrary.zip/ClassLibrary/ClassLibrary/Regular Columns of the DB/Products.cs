﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class Products
    { 
        public int ID { get; set; }

        public string prodName { get; set; }

        public string prodDescription { get; set; }

        public string prodBrand { get; set; }


    }
}
