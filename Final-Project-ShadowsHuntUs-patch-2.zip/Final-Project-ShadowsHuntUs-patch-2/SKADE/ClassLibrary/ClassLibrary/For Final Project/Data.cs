﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace ClassLibrary.For_Final_Project
{
     internal static class Data
    {
        static internal SqlConnection con = new SqlConnection();

        static Data()
        {
            con.ConnectionString = global::ClassLibrary.Properties.Settings.Default.EmmasConnectionString;
        }

        

    }
}
