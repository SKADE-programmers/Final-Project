﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using DataLibrary;
using System.Data;

namespace ClassLibrary.For_Final_Project
{
  public class WarrantySearch
    {
        public int ID { get; set; } 

        public DateTime serordDateIn { get; set; }

        public DateTime serordDateOut { get; set; }

        public string serordWarranty { get; set; }

  }
        
    
}
