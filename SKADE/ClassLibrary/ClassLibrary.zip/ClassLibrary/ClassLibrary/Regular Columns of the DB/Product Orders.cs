﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class Product_Orders
    {
        public int ID { get; set; }

        public int pordNumbers { get; set; }

        public DateTime pordDateOrdered { get; set; }

        public decimal pordPaid { get; set; }

    }
}
