﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class Positions
    {
        public int ID { get; set; }

        public string posName { get; set; }


    }
}
