﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class Payments
    {
        public int ID { get; set; }

        public string payTypes { get; set; }
    }
}
