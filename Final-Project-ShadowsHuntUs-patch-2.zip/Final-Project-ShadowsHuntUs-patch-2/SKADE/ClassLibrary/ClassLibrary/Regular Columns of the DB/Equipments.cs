﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class Equipments
    {
        
        public int ID { get; set; }

        public string equModels { get; set; }

        public int equSerialNum { get; set; }
        
        public Customers custID { get; set; }

        public Equip_Type equtypeID { get; set; }

        public Manufacturers equManuID { get; set; } 







    }
}
