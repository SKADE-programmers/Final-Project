﻿namespace DataLibrary
{


    partial class AuthDS
    {
        partial class DataTable1DataTable
        {
        }
    }
}
